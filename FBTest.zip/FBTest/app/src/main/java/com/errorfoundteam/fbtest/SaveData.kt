package com.errorfoundteam.fbtest

class SaveData (val name : String, val course : String){
    constructor():this ("","")
}